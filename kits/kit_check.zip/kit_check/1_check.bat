@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Check - AI automation from zero
where node >/dev/null 2>nul
if errorlevel 1 (
  echo.
  echo  [X] Node.js is not installed yet.
  echo      A guide page will open in your browser. Follow it, then run this file again.
  echo.
  start "" "%~dp0install_node.html"
  pause
  exit /b 1
)
node check.mjs
echo.
pause
