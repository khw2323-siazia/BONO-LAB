// AI 자동화 0부터 — 키트 ① 준비물 점검
// 이 컴퓨터에 따라 하기 준비물이 있는지 확인합니다. 아무것도 설치하거나 바꾸지 않습니다. 키·비밀번호는 묻지 않습니다.
// 결과는 같은 폴더의 check_result.txt 에도 남습니다.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const NEED_NODE = 18;

export function nodeCheck(version = process.versions.node) {
  const major = Number(String(version).split('.')[0]);
  if (major >= NEED_NODE) return { ok: true, line: `Node.js ${version} — 좋아요` };
  return { ok: false, line: `Node.js ${version} — 버전이 낮아요(${NEED_NODE} 이상 필요)`, fix: 'nodejs.org 에서 LTS(초록 버튼)를 받아 다시 설치하세요' };
}
export async function netCheck(fetchImpl = globalThis.fetch, timeoutMs = 6000) {
  try {
    const ac = new AbortController();
    const t = setTimeout(() => ac.abort(), timeoutMs);
    const r = await fetchImpl('https://www.googleapis.com/discovery/v1/apis?name=youtube', { signal: ac.signal });
    clearTimeout(t);
    return r && r.status < 500 ? { ok: true, line: '인터넷(구글 연결) — 좋아요' } : { ok: false, line: `인터넷 — 구글 응답 이상(${r?.status})`, fix: '잠시 뒤 다시 해 보세요' };
  } catch {
    return { ok: false, line: '인터넷 — 구글에 연결되지 않아요', fix: '와이파이·랜선을 확인하고, 회사 컴퓨터면 보안 프로그램이 막는지 확인하세요' };
  }
}
export function writeCheck(dir = HERE) {
  try {
    const f = path.join(dir, `.write_test_${process.pid}`);
    fs.writeFileSync(f, 'ok'); fs.rmSync(f, { force: true });
    return { ok: true, line: '이 폴더에 파일 쓰기 — 좋아요' };
  } catch {
    return { ok: false, line: '이 폴더에 파일을 쓸 수 없어요', fix: '키트 폴더를 바탕화면이나 문서 폴더로 옮긴 뒤 다시 실행하세요(압축 파일 안에서 바로 실행하면 안 돼요)' };
  }
}
export function diskCheck(dir = HERE, needGb = 2) {
  try {
    if (typeof fs.statfsSync !== 'function') return { ok: true, line: '남은 공간 — 확인 생략(Node 버전)' };
    const s = fs.statfsSync(dir);
    const gb = (Number(s.bavail) * Number(s.bsize)) / 1024 ** 3;
    return gb >= needGb ? { ok: true, line: `남은 공간 ${gb.toFixed(0)}GB — 좋아요` } : { ok: false, line: `남은 공간 ${gb.toFixed(1)}GB — 부족해요(${needGb}GB 이상)`, fix: '필요 없는 큰 파일을 지우세요' };
  } catch { return { ok: true, line: '남은 공간 — 확인 생략' }; }
}
export function osLine() {
  const p = process.platform === 'win32' ? '윈도우' : process.platform === 'darwin' ? '맥' : process.platform;
  return `컴퓨터: ${p} · ${os.arch()}`;
}
export async function runChecks({ fetchImpl = globalThis.fetch, dir = HERE, net = true } = {}) {
  const rows = [nodeCheck(), writeCheck(dir), diskCheck(dir)];
  if (net) rows.push(await netCheck(fetchImpl));
  const ok = rows.every((r) => r.ok);
  const L = ['=== AI 자동화 0부터 · 준비물 점검 ===', osLine(), ''];
  for (const r of rows) { L.push(`${r.ok ? '[O]' : '[X]'} ${r.line}`); if (!r.ok && r.fix) L.push(`    → ${r.fix}`); }
  L.push('', ok ? '모두 준비됐어요! 다음은 유튜브 연결 키트(4편)예요.' : '[X] 표시를 먼저 고치고, 이 파일을 다시 실행하세요.');
  return { ok, rows, text: L.join('\n') };
}

const isMain = (() => { try { return import.meta.url === pathToFileURL(process.argv[1] || '').href; } catch { return false; } })();
if (isMain) {
  const r = await runChecks({ net: !process.argv.includes('--no-net') });
  console.log(r.text);
  if (!process.argv.includes('--plain')) { try { fs.writeFileSync(path.join(HERE, 'check_result.txt'), '﻿' + r.text + '\n'); } catch { /* 저장 못 해도 화면 결과로 충분 */ } }
  process.exitCode = r.ok ? 0 : 1;
}
