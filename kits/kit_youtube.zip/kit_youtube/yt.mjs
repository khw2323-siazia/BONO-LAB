// AI 자동화 0부터 — 키트 ② 유튜브 연결·올리기 (Node.js 18 이상, 따로 설치할 것 없음)
//   node yt.mjs connect : 이 폴더의 client_secret…json(구글에서 받은 파일)으로 내 유튜브 채널을 연결 → my_key.json 에 저장 → 연결된 채널 이름을 보여 줌
//   node yt.mjs upload  : videos 폴더의 .mp4 를 '비공개'로 올림(한 번에 3개까지). 같은 이름의 .txt 가 있으면 첫 줄 = 제목, 나머지 = 설명
// 키는 각자 자기 것입니다. my_key.json·client_secret…json 은 남에게 보내지 마세요. 이 프로그램은 구글 말고 다른 곳으로 아무것도 보내지 않습니다.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const AUTH = 'https://accounts.google.com/o/oauth2/v2/auth';
export const TOKEN = 'https://oauth2.googleapis.com/token';
export const API = 'https://www.googleapis.com/youtube/v3';
export const UPLOAD = 'https://www.googleapis.com/upload/youtube/v3/videos';
export const SCOPES = 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly';
export const MAX_PER_RUN = 3;
const qs = (o) => new URLSearchParams(o).toString();
const say = (s) => console.log(s);

// 구글에서 받은 파일 찾기: client_secret*.json (데스크톱 앱이어야 함)
export function findClient(dir = HERE) {
  const f = fs.readdirSync(dir).find((x) => /^client_secret.*\.json$/i.test(x));
  if (!f) return { ok: false, why: "이 폴더에 'client_secret…json' 파일이 없어요. 구글 클라우드 → 사용자 인증 정보 → 만든 클라이언트의 '다운로드'로 받은 파일을 이 폴더에 넣어 주세요." };
  let j;
  try { j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8').replace(/^﻿/, '')); } catch { return { ok: false, why: `${f} 파일을 읽지 못했어요(다시 받아 주세요).` }; }
  if (j.web && !j.installed) return { ok: false, why: "이 파일은 '웹 애플리케이션'용이에요. 클라이언트를 '데스크톱 앱'으로 다시 만들어 받아 주세요." };
  const c = j.installed;
  if (!c?.client_id || !c?.client_secret) return { ok: false, why: '파일 안에 client_id·client_secret 이 없어요(다시 받아 주세요).' };
  return { ok: true, file: f, id: c.client_id, secret: c.client_secret };
}
export function pkce() {
  const verifier = crypto.randomBytes(48).toString('base64url');
  const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
  return { verifier, challenge };
}
export function authUrl(client, redirect, state, challenge) {
  return `${AUTH}?${qs({ client_id: client.id, redirect_uri: redirect, response_type: 'code', scope: SCOPES, access_type: 'offline', prompt: 'consent', state, code_challenge: challenge, code_challenge_method: 'S256' })}`;
}
async function json(r) { let j = {}; try { j = await r.json(); } catch { /* 빈 응답 */ } return j; }
export async function exchange(fetchImpl, client, code, redirect, verifier) {
  const r = await fetchImpl(TOKEN, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: qs({ code, client_id: client.id, client_secret: client.secret, redirect_uri: redirect, grant_type: 'authorization_code', code_verifier: verifier }) });
  const j = await json(r);
  if (!r.ok || !j.refresh_token) throw new Error(j.error_description || j.error || `구글이 키를 주지 않았어요(HTTP ${r.status})`);
  return { refresh: j.refresh_token, access: j.access_token };
}
export async function accessToken(fetchImpl, client, refresh) {
  const r = await fetchImpl(TOKEN, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: qs({ client_id: client.id, client_secret: client.secret, refresh_token: refresh, grant_type: 'refresh_token' }) });
  const j = await json(r);
  if (!r.ok || !j.access_token) {
    const gone = /invalid_grant/i.test(String(j.error || ''));
    throw new Error(gone ? "연결이 풀렸어요. '1_connect.bat' 을 다시 눌러 주세요(구글 앱이 '테스트' 상태면 7일마다 풀려요 — '프로덕션'으로 바꾸면 안 풀려요)." : (j.error_description || j.error || `HTTP ${r.status}`));
  }
  return j.access_token;
}
export async function myChannel(fetchImpl, access) {
  const r = await fetchImpl(`${API}/channels?${qs({ part: 'snippet', mine: 'true' })}`, { headers: { Authorization: `Bearer ${access}` } });
  const j = await json(r);
  const it = j.items?.[0];
  if (!r.ok || !it) throw new Error('연결된 채널을 찾지 못했어요(이 구글 계정에 유튜브 채널이 있는지 확인하세요).');
  return { id: String(it.id), title: String(it.snippet?.title || '') };
}
export function saveKey(dir, rec) { fs.writeFileSync(path.join(dir, 'my_key.json'), JSON.stringify({ note: '이 파일은 남에게 보내지 마세요(내 유튜브에 올릴 수 있는 열쇠).', ...rec }, null, 2)); }
export function loadKey(dir) { try { return JSON.parse(fs.readFileSync(path.join(dir, 'my_key.json'), 'utf8')); } catch { return null; } }

// 브라우저에서 '허용'을 누르면 구글이 이 컴퓨터(127.0.0.1)로 돌려보낸다 → 그 주소를 잠깐 열어 두고 받는다
export function startCallback({ state, timeoutMs = 5 * 60000 } = {}) {
  return new Promise((started, failed) => {
    let finish;
    const code = new Promise((ok, bad) => { finish = (e, c) => (e ? bad(e) : ok(c)); });
    code.catch(() => {}); // 기다리는 쪽이 받는다
    let t = null;
    const srv = http.createServer((req, res) => {
      const u = new URL(req.url, 'http://127.0.0.1');
      if (u.pathname !== '/') { res.writeHead(404); res.end(); return; }
      const c = u.searchParams.get('code'), st = u.searchParams.get('state'), err = u.searchParams.get('error');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      if (err || !c || st !== state) { res.end('<meta charset="utf-8"><h2>연결하지 못했어요. 창을 닫고 다시 해 주세요.</h2>'); end(new Error(err ? `구글: ${err}` : '응답이 맞지 않아요')); return; }
      res.end('<meta charset="utf-8"><h2>연결됐어요! 이 창은 닫으셔도 됩니다.</h2>');
      end(null, c);
    });
    const end = (e, c) => { clearTimeout(t); srv.close(); finish(e, c); };
    srv.on('error', failed);
    srv.listen(0, '127.0.0.1', () => {
      t = setTimeout(() => end(new Error('5분 안에 허용하지 않아 멈췄어요. 다시 실행해 주세요.')), timeoutMs);
      started({ port: srv.address().port, code });
    });
  });
}
function openBrowser(url) {
  // 윈도우: cmd 를 거치지 않고 기본 브라우저로 연다(주소의 & · % 가 깨지지 않게)
  if (process.platform === 'win32') spawn('rundll32.exe', ['url.dll,FileProtocolHandler', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
  else spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
}

export async function connect({ dir = HERE, fetchImpl = globalThis.fetch, open = openBrowser, log = say, timeoutMs = 5 * 60000 } = {}) {
  const client = findClient(dir);
  if (!client.ok) { log(`[X] ${client.why}`); return { ok: false }; }
  const { verifier, challenge } = pkce();
  const state = crypto.randomBytes(12).toString('hex');
  const cb = await startCallback({ state, timeoutMs });
  const redirect = `http://127.0.0.1:${cb.port}`;
  log('브라우저가 열려요. 올릴 채널의 구글 계정으로 로그인하고, 채널을 고르는 화면이 나오면 올릴 채널을 고른 뒤 \'허용\'을 눌러 주세요.');
  log("('Google에서 확인하지 않은 앱' 화면이 나오면: 고급 → 이동을 누르면 됩니다 — 내가 만든 앱이라 그래요.)");
  const url = authUrl(client, redirect, state, challenge);
  try { open(url); } catch { /* 아래 주소로 */ }
  log(`(브라우저가 열리지 않으면 이 주소를 복사해 브라우저에 붙여 넣으세요)\n${url}`);
  let code;
  try { code = await cb.code; } catch (e) { log(`[X] ${e.message}`); return { ok: false }; }
  try {
    const t = await exchange(fetchImpl, client, code, redirect, verifier);
    const ch = await myChannel(fetchImpl, t.access);
    saveKey(dir, { refresh_token: t.refresh, channel: ch.title, channelId: ch.id, at: new Date().toISOString() });
    log('');
    log(`[O] 연결됐어요 → 채널: 「${ch.title}」`);
    log('    맞는 채널인지 꼭 확인하세요. 다른 채널이면 my_key.json 을 지우고 1_connect.bat 을 다시 눌러, 허용 화면에서 채널을 다시 고르세요.');
    return { ok: true, channel: ch.title };
  } catch (e) { log(`[X] ${e.message}`); return { ok: false }; }
}

export function pendingVideos(dir = HERE) {
  const vdir = path.join(dir, 'videos');
  if (!fs.existsSync(vdir)) return [];
  let done = {};
  try { done = JSON.parse(fs.readFileSync(path.join(dir, 'uploaded.json'), 'utf8')); } catch { /* 처음 */ }
  return fs.readdirSync(vdir).filter((f) => /\.mp4$/i.test(f) && !done[f]).sort().map((f) => {
    const base = f.replace(/\.mp4$/i, '');
    let title = base, description = '';
    try { const t = fs.readFileSync(path.join(vdir, `${base}.txt`), 'utf8').replace(/^﻿/, '').split(/\r?\n/); title = (t[0] || base).trim() || base; description = t.slice(1).join('\n').trim(); } catch { /* 글 없음 */ }
    return { file: f, path: path.join(vdir, f), title: title.slice(0, 100), description: description.slice(0, 4900) };
  });
}
export async function uploadOne(fetchImpl, access, v) {
  const size = fs.statSync(v.path).size;
  const meta = { snippet: { title: v.title, description: v.description, categoryId: '22' }, status: { privacyStatus: 'private', selfDeclaredMadeForKids: false } };
  const r1 = await fetchImpl(`${UPLOAD}?${qs({ uploadType: 'resumable', part: 'snippet,status' })}`, { method: 'POST', headers: { Authorization: `Bearer ${access}`, 'Content-Type': 'application/json; charset=UTF-8', 'X-Upload-Content-Type': 'video/mp4', 'X-Upload-Content-Length': String(size) }, body: JSON.stringify(meta) });
  const loc = r1.headers?.get?.('location');
  if (!r1.ok || !loc) { const j = await json(r1); throw new Error(j.error?.message || `올리기 시작 실패(HTTP ${r1.status})`); }
  const r2 = await fetchImpl(loc, { method: 'PUT', headers: { 'Content-Type': 'video/mp4', 'Content-Length': String(size) }, body: fs.readFileSync(v.path) });
  const j = await json(r2);
  if (!r2.ok || !j.id) throw new Error(j.error?.message || `올리기 실패(HTTP ${r2.status})`);
  return { id: j.id, url: `https://youtu.be/${j.id}` };
}
export async function upload({ dir = HERE, fetchImpl = globalThis.fetch, log = say, max = MAX_PER_RUN } = {}) {
  const client = findClient(dir);
  if (!client.ok) { log(`[X] ${client.why}`); return { ok: false, uploaded: [] }; }
  const key = loadKey(dir);
  if (!key?.refresh_token) { log("[X] 아직 연결 전이에요. '1_connect.bat' 을 먼저 눌러 주세요."); return { ok: false, uploaded: [] }; }
  const list = pendingVideos(dir);
  if (!list.length) { log("올릴 영상이 없어요. 'videos' 폴더에 .mp4 파일을 넣어 주세요(같은 이름의 .txt 첫 줄 = 제목)."); return { ok: true, uploaded: [] }; }
  let access;
  try { access = await accessToken(fetchImpl, client, key.refresh_token); } catch (e) { log(`[X] ${e.message}`); return { ok: false, uploaded: [] }; }
  // 채널 섞임 막기: 연결할 때의 채널과 지금 채널이 같은지 먼저 확인
  try {
    const ch = await myChannel(fetchImpl, access);
    if (key.channelId && ch.id !== key.channelId) { log(`[X] 연결할 때 채널(「${key.channel}」)과 지금 채널(「${ch.title}」)이 달라요. 올리지 않고 멈춥니다. 1_connect.bat 으로 다시 연결해 주세요.`); return { ok: false, uploaded: [] }; }
    log(`채널 「${ch.title}」 에 올립니다 (비공개로).`);
  } catch (e) { log(`[X] ${e.message}`); return { ok: false, uploaded: [] }; }
  const donePath = path.join(dir, 'uploaded.json');
  let done = {}; try { done = JSON.parse(fs.readFileSync(donePath, 'utf8')); } catch { /* 처음 */ }
  const out = [];
  for (const v of list.slice(0, max)) {
    try {
      log(`올리는 중: ${v.file} …`);
      const r = await uploadOne(fetchImpl, access, v);
      done[v.file] = { id: r.id, url: r.url, at: new Date().toISOString() };
      fs.writeFileSync(donePath, JSON.stringify(done, null, 2));
      log(`[O] ${v.title} → ${r.url} (비공개 — 유튜브 스튜디오에서 확인하고 '공개'로 바꾸세요)`);
      out.push(r);
    } catch (e) { log(`[X] ${v.file}: ${e.message}`); break; }
  }
  if (list.length > max) log(`남은 영상 ${list.length - max}개는 다음에 다시 실행하면 올라가요(하루 올릴 수 있는 양이 정해져 있어요).`);
  return { ok: true, uploaded: out };
}

const isMain = (() => { try { return import.meta.url === pathToFileURL(process.argv[1] || '').href; } catch { return false; } })();
if (isMain) {
  const cmd = process.argv[2];
  if (cmd === 'connect') await connect();
  else if (cmd === 'upload') await upload();
  else say('사용법: node yt.mjs connect | upload');
}
