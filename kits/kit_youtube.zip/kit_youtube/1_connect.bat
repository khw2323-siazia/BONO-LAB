@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Connect YouTube - AI automation from zero
where node >/dev/null 2>nul
if errorlevel 1 (
  echo  [X] Node.js is not installed. Run the "check" kit first.
  pause
  exit /b 1
)
node yt.mjs connect
echo.
pause
